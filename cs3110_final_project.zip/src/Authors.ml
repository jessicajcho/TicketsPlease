(** hours_worked is the cumulative hours worked. MS1: 58 Hours, MS2: 39
    Hours, MS3: 72*)
let hours_worked = 169
